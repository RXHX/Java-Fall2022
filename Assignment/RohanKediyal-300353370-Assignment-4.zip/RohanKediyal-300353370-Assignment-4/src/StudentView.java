import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JComboBox;
import java.awt.List;
import javax.swing.JList;
import javax.swing.LayoutStyle.ComponentPlacement;
public class StudentView extends JFrame {

	private JPanel starter;

	public static StudentModel[] studentInfo = new StudentModel[10];
	private JComboBox comboBox;
	private JList lstCourses;
	/**
	 * Launch the application.
	 */
	
	
	
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					studentInfo	=  StudentController.dBDemo();
					StudentView frame = new StudentView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	public  void setUpComponent()
	{
		
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		starter = new JPanel();
		starter.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(starter);
		makeComboBox();
		
		
	}
	
	public void makeComboBox()
	{
		
		comboBox = new JComboBox();
		String[] students = { " ",studentInfo[0].getsName()+"("+studentInfo[0].getsID()+")",studentInfo[3].getsName()+"("+studentInfo[3].getsID()+")",studentInfo[5].getsName()+"("+studentInfo[5].getsID()+")"};
		comboBox.addItem(students);
		DefaultComboBoxModel model = new DefaultComboBoxModel(students);
		comboBox.setModel(model);

		
		String[] subjects = {
				studentInfo[0].getcCode()+"-"+studentInfo[0].getcTitle(),
				studentInfo[1].getcCode()+"-"+studentInfo[1].getcTitle(),
				studentInfo[2].getcCode()+"-"+studentInfo[2].getcTitle(),
				studentInfo[3].getcCode()+"-"+studentInfo[3].getcTitle() };
		DefaultListModel<String> courseNames = new DefaultListModel<>();
		
		
		
		for (String c : subjects) {
			courseNames.addElement(c);
		}
		
		
		lstCourses = new JList(courseNames);
		lstCourses.setBackground(Color.white);

		lstCourses.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		

		GroupLayout gl_starter = new GroupLayout(starter);
		gl_starter.setHorizontalGroup(
			gl_starter.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_starter.createSequentialGroup()
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 166, GroupLayout.PREFERRED_SIZE)
					.addGap(248))
		);
		gl_starter.setVerticalGroup(
			gl_starter.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_starter.createSequentialGroup()
					.addContainerGap()
					.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(218, Short.MAX_VALUE))
		);
		starter.setLayout(gl_starter);
		
	}

	/**
	 * Create the frame.
	 */
	public StudentView() {
		setUpComponent();
	
	}

}
