
public class StudentModel {
	public StudentModel() {
		super();
	}
	public StudentModel(String sName, String sID, String cCode, String cTitle, String grade) {
		super();
		this.sName = sName;
		this.sID = sID;
		this.cCode = cCode;
		this.cTitle = cTitle;
		this.grade = grade;
	}
	
	
	public String sName;
	public String sID;
	public String cCode;
	public String cTitle;
	public String grade;
	
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsID() {
		return sID;
	}
	public void setsID(String sID) {
		this.sID = sID;
	}
	public String getcCode() {
		return cCode;
	}
	public void setcCode(String cCode) {
		this.cCode = cCode;
	}
	public String getcTitle() {
		return cTitle;
	}
	public void setcTitle(String cTitle) {
		this.cTitle = cTitle;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}

	
	
	
}
