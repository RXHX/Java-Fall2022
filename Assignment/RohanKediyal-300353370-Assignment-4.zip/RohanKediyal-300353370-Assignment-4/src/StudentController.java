import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentController {

	public static Connection connection = null;
	public static Statement statement = null;
	public static ResultSet resultSet = null;
    public static StudentModel[] students = new StudentModel[10];
	
	public static StudentModel[] dBDemo() {

		
		
		// Step 1: Loading the ucanaccess driver
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("Unable to load driver.");
			e.printStackTrace();
		}

		try {
			String msAccDB = "Studentcourse.accdb";
			String dbURL = "jdbc:ucanaccess://" + msAccDB;

			// Step 2.A: Creating and getting connection
			connection = DriverManager.getConnection(dbURL);

			// Step 2.B: Creating JDBC Statement
			statement = connection.createStatement();

			// Step 2.C: Executing SQL query and process results if any
			String sqlStr = "SELECT * FROM Grades" + "";
			resultSet = statement.executeQuery(sqlStr);
            int index = 0;
			while (resultSet.next()) {
				StudentModel std =  new StudentModel();
				 std.setsName(resultSet.getString("sName"));
				 std.setsID(resultSet.getString("sID"));
				 std.setcCode(resultSet.getString("cCode"));
				 std.setcTitle(resultSet.getString("cTitle"));
				 std.setGrade(resultSet.getString("grade"));
				 students[index] = std;
				 index++;
			}

			// Step 3: Close the connection
			connection.close();
			statement.close();
			resultSet.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return students;

	}
	
	
	
	
	
	
	
	
	
	
	
}
